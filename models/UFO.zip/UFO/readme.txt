=============================================================================

Title                   :Ufo model for Quake 2

Filename                :ufo.zip

Author                  :Richard Clark aka GiB

E-Mail                  :g.i.b@lineone.net
			 Send any bug info to the above E-Mail

Homepage		:http://www.inside3d.com/gib

Description             :This is my second addition to the ppm's out there.
			 My first being the Sheep model

=============================================================================


* Contruction *

Model                   :New from scratch
Base Model Construction :GiB
Anims			:GiB
Skins	                :GiB, 5 of them
Editor(s) Used          :qME, NST, 3DS MAX
Known Bugs              :None

GiB:  Goto my page (http://www.inside3d.com/gib) to get loads of Quake2 PPM's
      I have got 35 at last count. All my other modelling work is there.

Visit http://inferno.3dportal.com if you're looking for Shadow Warrior TC's.
Because this one will be the be all and end all. The Last Warrior.

-GiB